# Boids Simulation System (DirectX 11)

このプロジェクトは、Compute Shader を用いて Boids アルゴリズムによる群衆シミュレーションを行う DirectX11 ベースの実装です。

## ✨ 概要

- Compute Shader による並列更新処理
- Geometry Shader によるパーティクルの拡張描画
- テクスチャは `particle.png` を使用
- 呼び出し関数：`LaunchBoidsSimulation(...)`

## 🔧 使用方法（参考）

このソース群は、**DirectX 11 環境での GPU パーティクルシステム構築の一例として提示されたものです。**  
実行にあたっては、シェーダバイナリ（.csoファイル）やテクスチャ、メインループなどの開発環境が必要となります。

```cpp
// 準備
BoidsSimulationSystem boids;
boids.Init();
boids.SetTexture(texture);  // particle.png を読み込んだ Texture

// 更新・描画ループ
boids.Update();
boids.RenderDisp(camera);
```

## 🧪 動作環境

- Visual Studio 2022
- Windows 10 以降
- DirectX 11 対応 GPU

## ⚠️ 注意事項

このコードは参考として、実装済みのものを抜粋し **AI により整形したものです**。  
ポートフォリオ提示用の参考例としてご活用ください。


## 📁 フォルダ構成（推奨）

```
BoidsPortfolio/
├─ src/
│   ├─ *.cpp, *.h
├─ shaders/
│   ├─ BoidsDisp_VS.hlsl
│   ├─ BoidsDisp_GS.hlsl
│   ├─ BoidsDisp_PS.hlsl
│   └─ BoidsComputeShader_Commented.hlsl
├─ textures/
│   ├─ particle.png
│   └─ particle2.png
├─ README.md
```

CSO バイナリは各 .hlsl を fxc などでビルドしてください。
