#include "BoidsSimulationSystem.h"
#include "MXsystem.h"
#include "MxTexture.h"
#include "MXobj3dCamera.h"

#include <memory>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int)
{
    // システム初期化（仮想環境が必要）
    if (!MX_DX->Initialize(L"Boids Simulation", 1280, 720)) {
        return -1;
    }

    // カメラ作成
    std::shared_ptr<MXobj3dCamera> camera = std::make_shared<MXobj3dCamera>();
    camera->SetEyePosition({0.0f, 0.0f, -20.0f});
    camera->SetLookAt({0.0f, 0.0f, 0.0f});

    // Boidsシステムの初期化
    BoidsSimulationSystem boids;
    boids.Init();

    // パーティクルテクスチャ読み込み
    std::shared_ptr<Texture> particleTex = std::make_shared<Texture>();
    if (!particleTex->LoadTexture(L"particle.png")) {
        MessageBoxA(NULL, "particle.png の読み込みに失敗しました。", "Error", MB_ICONERROR);
        return -1;
    }

    // ループ
    while (MX_DX->UpdateWindowLoop()) {
        // Boids更新（GPU）
        boids.Update();

        // 描画開始
        MX_DX->BeginScene();

        // 描画
        boids.RenderDisp(camera.get());

        // 描画終了
        MX_DX->EndScene();
    }

    return 0;
}
