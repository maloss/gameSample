#include "BoidsSimulationSystem.h"
#include "MXsystem.h"

// 初期化：デバイス・シェーダ・バッファの作成
void BoidsSimulationSystem::Init()
{
    HRESULT hr;

    boidCount = AiSample3_3D_PIECE_NO;
    chainA = 0;
    chainB = 1;
    m_pDevice = MX_DX->m_pDevice;
    m_pDeviceContext = MX_DX->m_pDeviceContext;

    // 頂点レイアウト
    D3D11_INPUT_ELEMENT_DESC layout[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,
          D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };
    m_pDeviceContext->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_POINTLIST);

    // シェーダ読み込み
    hr = create_vs_from_cso(m_pDevice, "shader/BoidsDisp_VS.cso", &g_pDispVS.p, &m_pVertexLayout.p, layout, 1);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    hr = create_ps_from_cso(m_pDevice, "shader/BoidsDisp_PS.cso", &g_pDispPS.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    hr = create_gs_from_cso(m_pDevice, "shader/BoidsDisp_GS.cso", &g_pDispGS.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    // 定数バッファ
    {
        D3D11_BUFFER_DESC desc = {};
        desc.Usage = D3D11_USAGE_DYNAMIC;
        desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        desc.ByteWidth = sizeof(ConstantBuffer);
        hr = m_pDevice->CreateBuffer(&desc, nullptr, &g_pConstantBuffer);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    }

    // Compute Shader
    hr = create_cs_from_cso(m_pDevice, "shader/BoidsCompute_CS.cso", &g_pComputeShader.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    // バッファ作成
    hr = CreateResource();
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    // SRV作成
    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = DXGI_FORMAT_UNKNOWN;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;
    srvDesc.Buffer.ElementWidth = boidCount;
    hr = m_pDevice->CreateShaderResourceView(g_pBuffer[0].p, &srvDesc, &g_pSRV[0].p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
}

// 外部から呼び出してテクスチャを設定
void BoidsSimulationSystem::SetTexture(std::shared_ptr<Texture> tex)
{
    this->particleTexture = tex;
}

// 描画処理
void BoidsSimulationSystem::RenderDisp(MXobj3dCamera* camera)
{
    // テクスチャが未設定なら描画しない
    if (!particleTexture) return;

    // SRVセット
    ID3D11ShaderResourceView* srv = particleTexture->GetSRV();
    m_pDeviceContext->PSSetShaderResources(0, 1, &srv);

    // サンプラーセット（仮：グローバルで初期化済と仮定）
    extern ID3D11SamplerState* g_pSamplerLinear;
    m_pDeviceContext->PSSetSamplers(0, 1, &g_pSamplerLinear);

    // シェーダ設定
    m_pDeviceContext->VSSetShader(g_pDispVS.p, nullptr, 0);
    m_pDeviceContext->GSSetShader(g_pDispGS.p, nullptr, 0);
    m_pDeviceContext->PSSetShader(g_pDispPS.p, nullptr, 0);
    m_pDeviceContext->IASetInputLayout(m_pVertexLayout.p);

    // 定数バッファ更新（略）

    // 描画（頂点バッファはCS側から生成されている前提）
    m_pDeviceContext->Draw(boidCount, 0);
}


HRESULT BoidsSimulationSystem::CreateResource()
{
    const int totalBoids = 1000;
    std::vector<VBuffer> posVertex(totalBoids);  // 各 Boid の初期データ格納用バッファ

    for (int i = 0; i < totalBoids; ++i) {
        // Boid の初期位置を格子状に配置（20×50 グリッド）
        posVertex[i].Position = { (i % 20 - 10) * 0.5f, 0.0f, (i / 20 - 10) * 0.5f };

        // 初期力ベクトル（外力）はゼロに
        posVertex[i].Force = { 0.0f, 0.0f, 0.0f };

        // ランダムなY軸回転を与えて進行方向を決定
        float rad = XMConvertToRadians((float)(rand() % 360));
        XMMATRIX rot = XMMatrixRotationY(rad);

        // 単位前方ベクトルを回転して方向ベクトルを生成
        XMVECTOR dir = XMVector3TransformNormal({ 0.0f, 0.0f, 1.0f }, rot);

        // 速度ベクトルとして 0.1 倍スケーリングして格納（ゆるやかに移動開始）
        XMStoreFloat3(&posVertex[i].Velocity, XMVectorScale(dir, 0.1f));
    }

    // GPU上の StructuredBuffer の設定
    D3D11_BUFFER_DESC bd = {};
    bd.ByteWidth = sizeof(VBuffer) * totalBoids;  // 全 Boid データの合計サイズ
    bd.Usage = D3D11_USAGE_DEFAULT;               // 書き換え不可（初期化時のみ設定）
    bd.BindFlags = D3D11_BIND_SHADER_RESOURCE;    // シェーダから読み取り可能にする
    bd.CPUAccessFlags = 0;
    bd.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED;  // 構造化バッファとして使用
    bd.StructureByteStride = sizeof(VBuffer);     // 1要素のサイズを指定

    // 初期データを渡すための構造体
    D3D11_SUBRESOURCE_DATA initData = {};
    initData.pSysMem = posVertex.data();  // CPU 側で準備した Boid データ

    // GPU バッファ生成
    HRESULT hr = m_device->CreateBuffer(&bd, &initData, &m_inputBuffer);
    if (FAILED(hr)) return hr;

    // シェーダリソースビュー（SRV）の設定
    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = DXGI_FORMAT_UNKNOWN;  // 構造化バッファの場合は UNKNOWN
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;
    srvDesc.Buffer.ElementOffset = 0;
    srvDesc.Buffer.ElementWidth = totalBoids;

    // SRV を作成して HLSL からアクセス可能に
    hr = m_device->CreateShaderResourceView(m_inputBuffer.Get(), &srvDesc, &m_srv);
    if (FAILED(hr)) return hr;

    return S_OK;
}