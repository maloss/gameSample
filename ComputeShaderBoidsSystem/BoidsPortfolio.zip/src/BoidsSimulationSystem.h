#pragma once

#include <d3d11.h>
#include <wrl/client.h>
#include <DirectXMath.h>
#include <memory>
#include "MxTexture.h"

using namespace DirectX;
using Microsoft::WRL::ComPtr;

// GPU側定数バッファ構造体
struct ConstantBuffer {
    XMFLOAT4X4 View;
    XMFLOAT4X4 Projection;
    XMFLOAT2   ParticleSize;
    INT32      BoidIndex;
    float      padding;
    XMFLOAT4   EyePosition;
    XMFLOAT4   FogColor;
    float      FogNear;
    float      FogFar;
    float      dummy1;
    float      dummy2;
};

// ボイドシミュレーション用構造体
struct BoidData {
    XMFLOAT3 Position;
    XMFLOAT3 Velocity;
    XMFLOAT3 Force;
};

class MXobj3dCamera;

class BoidsSimulationSystem {
public:
    void Init();                                      // 初期化
    void Update();                                    // フレーム更新
    void RenderDisp(MXobj3dCamera* camera);           // 描画
    void SetTexture(std::shared_ptr<Texture> tex);    // テクスチャ設定

private:
    HRESULT CreateResource();                         // バッファ生成
    HRESULT ComputeShader();                          // Boids更新（GPU）

    ID3D11Device* m_pDevice = nullptr;
    ID3D11DeviceContext* m_pDeviceContext = nullptr;

    ComPtr<ID3D11Buffer> g_pBuffer[2];           // Ping-Pongバッファ
    ComPtr<ID3D11ShaderResourceView> g_pSRV[2];
    ComPtr<ID3D11UnorderedAccessView> g_pUAV[2];
    ComPtr<ID3D11Buffer> g_pConstantBuffer;

    ComPtr<ID3D11ComputeShader> g_pComputeShader;
    ComPtr<ID3D11VertexShader>  g_pDispVS;
    ComPtr<ID3D11GeometryShader> g_pDispGS;
    ComPtr<ID3D11PixelShader>   g_pDispPS;
    ComPtr<ID3D11InputLayout>   m_pVertexLayout;

    int boidCount = 0;
    int chainA = 0;
    int chainB = 1;

    std::shared_ptr<Texture> particleTexture = nullptr;
};
