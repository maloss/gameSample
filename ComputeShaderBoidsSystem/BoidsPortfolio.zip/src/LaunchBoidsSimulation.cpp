#include "BoidsSimulationSystem.h"
#include <windows.h>
#include <d3d11.h>
#include <memory>
#include <mutex>

enum class BoidsState {
    Uninitialized,
    Running
};

static BoidsState boidsState = BoidsState::Uninitialized;
static std::unique_ptr<BoidsSimulationSystem> boids;
static std::once_flag initFlag;

// 毎フレーム呼び出される処理（初回に Init、以降は Update + Render）
void LaunchBoidsSimulation(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11ShaderResourceView* texture) {
    std::call_once(initFlag, [&]() {
        boids = std::make_unique<BoidsSimulationSystem>();
        boids->Init(device, context);      // 初期位置・速度は CreateResource() 内で自動設定
        boids->SetTexture(texture);
        boidsState = BoidsState::Running;
    });

    if (boidsState == BoidsState::Running) {
        boids->Update();
        boids->Render();
    }
}
