#include "BoidsSimulationSystem.h"
#include "MXsystem.h"
#include "MxTexture.h"
#include "MXobj3dCamera.h"
#include <memory>

// この関数はアプリ側から呼び出される使用例として提供されます。
// DirectX や MXsystem がすでに初期化済みであることが前提です。

void LaunchBoidsSimulation(ID3D11Device* device,
                           ID3D11DeviceContext* context,
                           const wchar_t* texturePath,
                           MXobj3dCamera* camera)
{
    // Boidsシステムの構築
    BoidsSimulationSystem boids;
    boids.Init();

    // テクスチャ読み込み（呼び出し側で必要に応じて設定）
    std::shared_ptr<Texture> particleTexture = std::make_shared<Texture>();
    if (!particleTexture->LoadTexture(texturePath)) {
        OutputDebugStringA("Error: particle texture file not found: particle.png\n");
        return;
    }

    // 簡易ループ：60フレームだけBoidsを更新・描画
    for (int i = 0; i < 60; ++i)
    {
        boids.Update();
        boids.RenderDisp(camera);
    }
}
