# Hermite Curve Sample (C++)

このプロジェクトは、**Hermite補間** を用いたスムーズな移動経路を C++ でシミュレーションするサンプル実装です。

## ✨ 概要

- 指定された始点・終点と、各点の速度ベクトルから Hermite 曲線を生成
- 加速・減速付きのタイムステップ制御
- 実行例関数：`LaunchHermiteSample()`

## 🔧 使用方法（参考）

このコード群は、**ゲーム開発などにおける移動経路補間アルゴリズムの一例**として提示されたものです。  
描画処理は含まれていないため、座標・速度などの出力はコンソール上で確認できます。

```cpp
// 使用例
LaunchHermiteSample();
```

## 🧪 動作環境

- Visual Studio 2022
- Windows 10 以降
- C++17 以上推奨

## ⚠️ 注意事項

このコードは参考として、実装済みのものを抜粋し **AI により整形したものです**。  
ポートフォリオ提示用の参考例としてご活用ください。

## 📁 フォルダ構成（推奨）

```
HermitePortfolio/
├─ src/
│   ├─ HermiteCurve.cpp
│   ├─ HermiteCurve.h
│   └─ LaunchHermiteSample.cpp
├─ README.md
```
