#include "HermiteCurve.h"

// 初期化：補間パラメータと3次式の係数を設定
void Hermite::init(V3 p0, V3 v0, V3 p1, V3 v1, float _startDt, float _accel, float _maxDt)
{
    startDt = _startDt;    // 開始時の時間ステップ
    accel = _accel;        // 加速度
    maxDt = _maxDt;        // 最大速度に相当

    float dx = p1.x - p0.x;
    float dy = p1.y - p0.y;
    float dz = p1.z - p0.z;

    t = 0.0f;              // 補間パラメータ（0.0～1.0）
    dt = startDt;          // 現在の進行速度（時間ステップ）

    // 三次エルミート補間の係数（P(t) = k3*t^3 + k2*t^2 + k1*t + k0）
    k0.x = p0.x;
    k1.x = v0.x;
    k2.x = 3 * dx - 2 * v0.x - v1.x;
    k3.x = -2 * dx + v0.x + v1.x;

    k0.y = p0.y;
    k1.y = v0.y;
    k2.y = 3 * dy - 2 * v0.y - v1.y;
    k3.y = -2 * dy + v0.y + v1.y;

    k0.z = p0.z;
    k1.z = v0.z;
    k2.z = 3 * dz - 2 * v0.z - v1.z;
    k3.z = -2 * dz + v0.z + v1.z;
}

// 時間を進めて、補間パラメータtを更新する
float Hermite::move()
{
    // 加速付きで dt を変化させる（イージング的な演出にも使える）
    if (dt > maxDt) {
        dt -= accel;
    } else {
        dt += accel;
    }

    endDt = dt;   // 現在のdtを保存

    t += dt;      // 時間パラメータを更新
    if (t > 1.0f) t = 1.0f;

    return t;
}

// 現在の位置と接線（速度）ベクトルを更新する
void Hermite::update()
{
    float t1 = t;
    float t2 = t1 * t1;
    float t3 = t1 * t2;

    // 位置 = k3*t^3 + k2*t^2 + k1*t + k0
    pos.x = k3.x * t3 + k2.x * t2 + k1.x * t1 + k0.x;
    pos.y = k3.y * t3 + k2.y * t2 + k1.y * t1 + k0.y;
    pos.z = k3.z * t3 + k2.z * t2 + k1.z * t1 + k0.z;

    // 接線ベクトル（速度）= P'(t) = 3k3*t^2 + 2k2*t + k1
    tan.x = 3 * k3.x * t2 + 2 * k2.x * t1 + k1.x;
    tan.y = 3 * k3.y * t2 + 2 * k2.y * t1 + k1.y;
    tan.z = 3 * k3.z * t2 + 2 * k2.z * t1 + k1.z;
}
