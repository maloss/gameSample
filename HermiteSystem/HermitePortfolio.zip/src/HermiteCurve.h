#pragma once
#include <DirectXMath.h>

// 3次元ベクトル型（DirectX::XMFLOAT3の別名）
typedef DirectX::XMFLOAT3 V3;

// Hermite曲線による制御用クラス
struct Hermite
{
    V3 k0, k1, k2, k3;   // 制御点
    float t, dt;         // パラメータ
    V3 pos;              // 現在位置
    V3 tan;              // 接線ベクトル（速度）
    float startDt;       // 開始時の速度
    float accel;         // 加速度
    float endDt;         // 終了時の速度
    float maxDt;         // 最大速度

    // 初期化
    void init(V3 p0, V3 v0, V3 p1, V3 v1, float startDt, float accel, float maxDt);
    // 時間を進めて現在位置を計算（戻り値は速度）
    float move();
    // 現在の位置と接線を更新
    void update();
};
