// HermiteCurve を使ったサンプル実行関数
void LaunchHermiteSample() {
    V3 p0 = { 0.0f, 0.0f, 0.0f };     // 開始位置
    V3 v0 = { 5.0f, 10.0f, 0.0f };    // 開始速度
    V3 p1 = { 30.0f, 0.0f, 0.0f };    // 終了位置
    V3 v1 = { 5.0f, -5.0f, 0.0f };    // 終了速度

    float startDt = 0.01f;
    float accel = 0.002f;
    float maxDt = 0.05f;

    Hermite hermite;
    hermite.init(p0, v0, p1, v1, startDt, accel, maxDt);

    std::cout << "=== Hermite curve simulation ===\n";

    while (hermite.t < 1.0f) {
        float velocity = hermite.move();   // 時間を進める
        hermite.update();                  // 座標・速度を更新
        PrintVec(hermite.pos, "Position");
        PrintVec(hermite.tan, "Velocity");
        std::cout << "----------------------------------\n";
        Sleep(50); // 50ms ウェイト
    }

    std::cout << "到達しました。\n";
}
