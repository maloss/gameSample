# Particle FX System (DirectX 11)

このプロジェクトは、**Compute Shader を用いた GPU パーティクルシステム**の最小構成サンプルです。  
ゲームやツールにおける一斉エフェクト（例：爆発・閃光・煙）などを想定して設計されています。

## ✨ 概要

- Compute Shader によるパーティクルの並列更新
- Geometry Shader による描画表現の拡張
- パーティクル画像（`particles.png`）を使用
- 呼び出し関数：`LaunchParticleFXSample(...)`

## 🔧 使用方法（参考）

このコード群は、**DirectX 11 を使った GPU 処理ベースのパーティクル表現の一例**として提示されたものです。  
実行にはシェーダーのビルド（CSO化）や、描画ループを含む環境構築が必要です。

```cpp
// 毎フレーム呼び出す処理（例：タイマー割り込みやフレームループ内など）
LaunchParticleFXSample(device, context, texture);
```

初回呼び出しで初期化され、以降の呼び出しではパーティクルの `Update` / `Render` が実行されます。  
すべてのパーティクルが消滅すると、自動で初期状態に戻り、次回の初回呼び出しで再度初期化されます。

## 🧪 動作環境

- Visual Studio 2022
- Windows 10 以降
- DirectX 11 対応 GPU

## ⚠️ 注意事項

このコードは参考として、実装済みのものを抜粋し **AI により整形したものです**。  
ポートフォリオ提示用の参考例としてご活用ください。

## 📁 フォルダ構成（推奨）

```
ParticleFXPortfolio/
├─ src/
│   ├─ PerticlesComp.cpp
│   ├─ PerticlesComp.h
│   ├─ PerticlesDispNo.h
│   └─ LaunchParticleFXSample.cpp
├─ shaders/
│   ├─ PerticlesCS.hlsl
│   ├─ PerticlesDisp.hlsli
│   ├─ PerticlesDispGS.hlsl
│   ├─ PerticlesDispPS.hlsl
│   └─ PerticlesDispVS.hlsl
├─ textures/
│   └─ particles.png
├─ README.md
```

各 .hlsl は fxc などで CSO にビルドしてご利用ください。
