#include "PerticlesComp.h"
#include "PerticlesDispNo.h"
#include <windows.h>
#include <d3d11.h>
#include <memory>
#include <DirectXMath.h>
#include <cstdlib>
#include <mutex>

enum class FXState {
    Uninitialized,
    Running
};

static FXState fxState = FXState::Uninitialized;
static std::unique_ptr<OneCallParticleFXSystem> fx;
static std::once_flag initFlag;

// ランダムユーティリティ
float RandomRange(float min, float max) {
    return min + static_cast<float>(rand()) / (static_cast<float>(RAND_MAX / (max - min)));
}

// 初期化処理（1度だけ呼ばれる）
void InitFX(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11ShaderResourceView* texture) {
    using namespace DirectX;

    fx = std::make_unique<OneCallParticleFXSystem>();
    fx->Init(device, context);
    fx->SetTexture(texture);

    for (int i = 0; i < 1000; ++i) {
        int kind = 1 + rand() % 3;

        V3 pos = {
            RandomRange(-50.0f, 50.0f),
            RandomRange(-50.0f, 50.0f),
            RandomRange(-50.0f, 50.0f)
        };

        V3 vel = {
            RandomRange(-1.0f, 1.0f),
            RandomRange(0.5f, 2.0f),
            RandomRange(-1.0f, 1.0f)
        };

        V2 size = {10.0f, 10.0f};

        fx->PerticleSet(kind, pos, vel, size);
    }

    fxState = FXState::Running;
}

// 毎フレーム呼び出す処理（ステートマシンベース）
void LaunchParticleFXStep(ID3D11Device* device, ID3D11DeviceContext* context, ID3D11ShaderResourceView* texture) {
    std::call_once(initFlag, [&]() {
        InitFX(device, context, texture);
    });

    if (fxState == FXState::Running) {
        fx->Update();
        fx->Render();

        // 全てのパーティクルが消えたら初期状態へ戻す
        if (!fx->IsActive()) {
            fxState = FXState::Uninitialized;
            fx.reset();
            initFlag = std::once_flag(); // 再初期化を許可
        }
    }
}
