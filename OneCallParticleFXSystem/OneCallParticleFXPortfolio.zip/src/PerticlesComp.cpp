#define _CRT_RAND_S   // rand_sを使う
#include <stdlib.h>

#include "misc.h"
#include<memory>
#include "MxTexture.h"
#include <math.h>
#include <stdio.h>
#include <assert.h>  //アサートはstdio.hとセットでしか使えない
#include "MXsystem.h"
#include "PerticlesComp.h"
#include "MXmakeShader.h"
#include "MXobj3dCamera.h"
#include "MXobj3dLight.h"

extern float answerBuf2[];

/// <summary>
/// 初期化
/// </summary>
void PerticlesComp::Init() {

    HRESULT hr;

    //コンピュート計算のワークをセット

    //// **********************************************************
    chainA = 0;
    chainB = 1;
    m_pDevice = MX_DX->m_pDevice;
    m_pDeviceContext = MX_DX->m_pDeviceContext;

    // **********************************************************
    CreateShader();//シェーダーの作成
    CreateResource();//リソースの作成
    CreateView();//ビューの作成

    //テキスチャー
    render_texture = std::make_shared<Texture>();//これは実験
    render_texture->Load("perticles/particles.png");
    mx2dDx = std::make_unique<MX2dDX>();
    mx2dDx->Init2D();

    //アルファブレンド用ブレンドステート作成
    //pngファイル内にアルファ情報がある。アルファにより透過するよう指定している
    D3D11_BLEND_DESC bd;
    ZeroMemory(&bd, sizeof(D3D11_BLEND_DESC));
    bd.IndependentBlendEnable = false;
    bd.AlphaToCoverageEnable = false;
    bd.RenderTarget[0].BlendEnable = true;
    bd.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    bd.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
    bd.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bd.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
    bd.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
    bd.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    bd.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    hr = MX_DX->m_pDevice->CreateBlendState(&bd, &pBlendState.p);
    return;
}
void PerticlesComp::CreateShader(void)
{
    HRESULT hr;
    //描画用シェーダ
    // ダミー入力レイアウト
    //結局インプットアセンブラは使っていないので不要だが、ないと
    //VSが作れない。
    //今は頂点の入力はバッファで行っている。
    D3D11_INPUT_ELEMENT_DESC layout[] = {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0,      D3D11_INPUT_PER_VERTEX_DATA, 0 },
    };

    //各種シェーダーをセット
    //バーテックスシェーダー    レイアウトは向うでセットm_pVertexLayout
    hr = create_vs_from_cso(MX_DX->m_pDevice, "shader/PerticlesDispVS.cso", &g_pMxGpu_Disp_VS.p, &m_pVertexLayout.p, layout, 0);

    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    //ピクセルシェーダー
    hr = create_ps_from_cso(MX_DX->m_pDevice, "shader/PerticlesDispPS.cso", &g_pMxGpu_Disp_PS.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    //ジオメトリーシェーダー
    hr = create_gs_from_cso(MX_DX->m_pDevice, "shader/PerticlesDispGS.cso", &g_pMxGpu_Disp_GS.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    // **********************************************************
        // コンピュート・シェーダ

    hr = create_cs_from_cso(MX_DX->m_pDevice, "shader/PerticlesCS.cso", &g_pComputeShader2.p);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
}
void PerticlesComp::CreateView(void)
{
    HRESULT hr;
    {
        // **********************************************************
        // 入力ワークリソース ビューの設定（入力用）
        D3D11_SHADER_RESOURCE_VIEW_DESC DescSRV;
        ZeroMemory(&DescSRV, sizeof(DescSRV));
        DescSRV.Format = DXGI_FORMAT_UNKNOWN;
        DescSRV.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;

        DescSRV.Buffer.ElementWidth = PERTICLES_PIECE_NO; // データ数

                                            // シェーダ リソース ビューの作成
        hr = m_pDevice->CreateShaderResourceView(g_pBuffer[0].p, &DescSRV, &g_pSRV[0].p);

        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

        hr = m_pDevice->CreateShaderResourceView(g_pBuffer[1].p, &DescSRV, &g_pSRV[1].p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    }

    // **********************************************************
    // 出力ワーク用アンオーダード・アクセス・ビュー（出力用）
    {
        D3D11_UNORDERED_ACCESS_VIEW_DESC DescUAV;
        ZeroMemory(&DescUAV, sizeof(DescUAV));
        DescUAV.Format = DXGI_FORMAT_UNKNOWN;
        DescUAV.ViewDimension = D3D11_UAV_DIMENSION_BUFFER;
        DescUAV.Buffer.NumElements = PERTICLES_PIECE_NO; // データ数

                                                // アンオーダード・アクセス・ビューの作成
        hr = m_pDevice->CreateUnorderedAccessView(g_pBuffer[0].p, &DescUAV, &g_pUAV[0].p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

        hr = m_pDevice->CreateUnorderedAccessView(g_pBuffer[1], &DescUAV, &g_pUAV[1]);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
        // CPU転送用アンオーダード・アクセス・ビューの設定
        ZeroMemory(&DescUAV, sizeof(DescUAV));
        DescUAV.Format = DXGI_FORMAT_UNKNOWN;
        DescUAV.ViewDimension = D3D11_UAV_DIMENSION_BUFFER;
        DescUAV.Buffer.NumElements = PERTICLES_PIECE_NO; // データ数
        hr = m_pDevice->CreateUnorderedAccessView(g_pToCpuBuffer, &DescUAV, &g_pToCpuUAV);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    }

    // **********************************************************
    // 入力初期化ワークリソース ビューの設定
    {
        D3D11_SHADER_RESOURCE_VIEW_DESC DescSRV;
        ZeroMemory(&DescSRV, sizeof(DescSRV));
        DescSRV.Format = DXGI_FORMAT_UNKNOWN;
        DescSRV.ViewDimension = D3D11_SRV_DIMENSION_BUFFER;
        DescSRV.Buffer.ElementWidth = PERTICLES_PIECE_NO; // データ数
        // シェーダ リソース ビューの作成
        hr = m_pDevice->CreateShaderResourceView(g_pInitBuffer.p, &DescSRV, &g_pInitSRV.p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    }

}

void  PerticlesComp::CreateResource(void){
    HRESULT hr;
    // **********************************************************
    // 定数バッファの定義
    // **********************************************************
    {
        D3D11_BUFFER_DESC cBufferDesc;
        cBufferDesc.Usage = D3D11_USAGE_DYNAMIC;    // 動的(ダイナミック)使用法
        cBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER; // 定数バッファ
        cBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;     // CPUから書き込む
        cBufferDesc.MiscFlags = 0;
        cBufferDesc.StructureByteStride = 0;

        // 定数バッファの作成
        cBufferDesc.ByteWidth = sizeof(cbCBuffer); // バッファ・サイズ
        hr = m_pDevice->CreateBuffer(&cBufferDesc, NULL, &g_pCBuffer);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    }
    // **********************************************************
    //初期化用リソースの設定
    // **********************************************************
    {
        for (int i = 0; i < PERTICLES_PIECE_NO; ++i) {
            CpuGpuBuffers[i].Position = XMFLOAT3(0, 0, 0);
            CpuGpuBuffers[i].Kind = 0;
            CpuGpuBuffers[i].BusyFg = 0;
            CpuGpuBuffers[i].Step = 0;
            CpuGpuBuffers[i].Velocity = XMFLOAT3(0, 0, 0);
        }
        // ワークリソースの設定
        D3D11_BUFFER_DESC Desc;
        ZeroMemory(&Desc, sizeof(Desc));
        Desc.ByteWidth = PERTICLES_PIECE_NO * sizeof(CPUGPUBuffer); // バッファ サイズ
        Desc.Usage = D3D11_USAGE_DYNAMIC;//ステージの入出力はOK。GPUの入出力OK。
//        Desc.BindFlags = D3D11_BIND_UNORDERED_ACCESS | D3D11_BIND_SHADER_RESOURCE;
        Desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;//UNORDEREDのダイナミックはダメだった。
        Desc.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED; // 構造化バッファ
        Desc.StructureByteStride = sizeof(CPUGPUBuffer);
        Desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;     // CPUから書き込む
        D3D11_SUBRESOURCE_DATA SubResource;//サブリソースの初期化用データを定義
        SubResource.pSysMem = CpuGpuBuffers;
        SubResource.SysMemPitch = 0;
        SubResource.SysMemSlicePitch = 0;

        // 最初の入力リソース(データを初期化する)
        hr = m_pDevice->CreateBuffer(&Desc, &SubResource, &g_pInitBuffer.p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

    }
    // **********************************************************
    //ワークリソースの設定
    // **********************************************************
    {
        struct workBuffer* work = new workBuffer[PERTICLES_PIECE_NO];
        for (int i = 0; i < PERTICLES_PIECE_NO; ++i) {

            work[i].Position = XMFLOAT3(0, 0, 0);      // 座標値
            work[i].Velocity = XMFLOAT3(0, 0, 0);      // 速度
            work[i].Force = XMFLOAT3(0, 0, 0); // 加速度
            work[i].Kind = 0;       // 種類
            work[i].TexNo = 0;       // テキスチャーNO
            work[i].AniNo = 0;      // アニメNo
            work[i].Timer = 0;      // ダミー
            work[i].Alpha = 0;      //透明度
            work[i].Size = XMFLOAT2(0, 0);      //サイズ
            work[i].Angle = 0;      //回転角

        }

        // ワークリソースの設定
        D3D11_BUFFER_DESC Desc;
        ZeroMemory(&Desc, sizeof(Desc));
        Desc.ByteWidth = PERTICLES_PIECE_NO * sizeof(workBuffer); // バッファ サイズ
        Desc.Usage = D3D11_USAGE_DEFAULT;//ステージの入出力はOK。GPUの入出力OK。
        Desc.BindFlags = D3D11_BIND_UNORDERED_ACCESS | D3D11_BIND_SHADER_RESOURCE;
        Desc.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED; // 構造化バッファ
        Desc.StructureByteStride = sizeof(workBuffer);

        D3D11_SUBRESOURCE_DATA SubResource;//サブリソースの初期化用データを定義
        SubResource.pSysMem = work;
        SubResource.SysMemPitch = 0;
        SubResource.SysMemSlicePitch = 0;

        // 最初の入力リソース(データを初期化する)
        hr = m_pDevice->CreateBuffer(&Desc, &SubResource, &g_pBuffer[0].p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

        // 最初の出力リソース（初期化用データは必要ない）
        hr = m_pDevice->CreateBuffer(&Desc, &SubResource, &g_pBuffer[1].p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
        delete[] work;

    }

    // **********************************************************
    //CPUへデータ書き込み用バッファの作成（一度にCPUへは送れないのでここを経由）
    // **********************************************************
    {
    //    struct CPUGPUBuffer* cpuGpuData = new CPUGPUBuffer[PERTICLES_PIECE_NO];
        //    cpuGpuData[i].BusyFg = 1;//全部使っていない状態

        //}
        D3D11_BUFFER_DESC Desc;
        ZeroMemory(&Desc, sizeof(Desc));
        Desc.ByteWidth = PERTICLES_PIECE_NO * sizeof(CPUGPUBuffer); // バッファ サイズ
        Desc.Usage = D3D11_USAGE_DEFAULT;//ステージの入出力はOK。GPUの入出力OK。
        Desc.BindFlags = D3D11_BIND_UNORDERED_ACCESS | D3D11_BIND_SHADER_RESOURCE;
        Desc.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_STRUCTURED; // 構造化バッファ
        Desc.StructureByteStride = sizeof(CPUGPUBuffer);

        D3D11_SUBRESOURCE_DATA SubResource;//初期化サブリソースの初期化用データを定義
        SubResource.pSysMem = CpuGpuBuffers;
        SubResource.SysMemPitch = 0;
        SubResource.SysMemSlicePitch = 0;

        hr = m_pDevice->CreateBuffer(&Desc, &SubResource, &g_pToCpuBuffer.p);// CPUへの書き込み用バッファ リソース
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));

        // リードバック用バッファ リソースの作成
        ZeroMemory(&Desc, sizeof(Desc));
        Desc.ByteWidth = Desc.ByteWidth = PERTICLES_PIECE_NO * sizeof(CPUGPUBuffer);    // バッファ サイズ
        Desc.Usage = D3D11_USAGE_STAGING;  // CPUから読み書き可能なリソース
        Desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ; // CPUから読み込む
        Desc.StructureByteStride = sizeof(CPUGPUBuffer);//コンピュートシェーダーで構造体を扱う場合必要
        hr = m_pDevice->CreateBuffer(&Desc, NULL, &g_pStagingBuffer.p);
        _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    }
    return;
}
HRESULT PerticlesComp::Compute(void)
{
    m_pDeviceContext = MX_DX->m_pDeviceContext.p;
    // **********************************************************
    // コンピュート・シェーダを使った演算
    // **********************************************************
    HRESULT hr = S_OK;
    sendConstantBuffer();
    sendInitBuffer();

    // Compute Shader の設定
    m_pDeviceContext->CSSetShader(g_pComputeShader2, NULL, 0);
    // 定数バッファをセット
    m_pDeviceContext->CSSetConstantBuffers(0, 1, &g_pCBuffer.p);
    ID3D11ShaderResourceView* pViewNULL = NULL;

    // SRV の解除
    m_pDeviceContext->CSSetShaderResources(0, 1, &pViewNULL);
    m_pDeviceContext->CSSetShaderResources(1, 1, &pViewNULL);
    // UAV をセット
    m_pDeviceContext->CSSetUnorderedAccessViews(0, 1, &g_pUAV[chainB].p, NULL);
    m_pDeviceContext->CSSetUnorderedAccessViews(1, 1, &g_pToCpuUAV.p, NULL);

    // 書き込み SRV のセット
    m_pDeviceContext->CSSetShaderResources(0, 1, &g_pSRV[chainA].p);

    // 入力用 SRV（初期値）のセット
    m_pDeviceContext->CSSetShaderResources(1, 1, &g_pInitSRV.p);

    // Dispatch 実行
    m_pDeviceContext->Dispatch(PERTICLES_DISPATCH_NO, 1, 1);//グループの数
//    m_pDeviceContext->CopyResource(g_pVerBufferDrawFrom.p, g_pBuffer[0].p);

    // GPU→CPU への転送
    m_pDeviceContext->CopyResource(g_pStagingBuffer, g_pToCpuBuffer);
    // 結果をCPUから読み込む
    // CPU側読み出しのため Map
    D3D11_MAPPED_SUBRESOURCE MappedResource;
    hr = m_pDeviceContext->Map(g_pStagingBuffer, 0, D3D11_MAP_READ, 0, &MappedResource);
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    CPUGPUBuffer* pt = (CPUGPUBuffer*)MappedResource.pData;
    //resourceBufに転送

    memcpy(CpuGpuBuffers, pt, PERTICLES_PIECE_NO * sizeof(CPUGPUBuffer));

    // Map の解除
    m_pDeviceContext->Unmap(g_pStagingBuffer, 0);
    return hr;
}
/////////////////////////////////////////////////////////
//定数バッファに値を送る。
/////////////////////////////////////////////////////////
void PerticlesComp::sendConstantBuffer() {

//    m_pDeviceContext->UpdateSubresource(g_pCBuffer.p, 0, 0, &g_cbCBuffer, 0, 0);

    HRESULT hr = S_OK;
    // シェーダを設定
    g_cbCBuffer.No = PERTICLES_DISPATCH_NO;

    // ***************************************
    // 定数バッファのマップ取得

    D3D11_MAPPED_SUBRESOURCE MappedResource;
    hr = m_pDeviceContext->Map(
        g_pCBuffer,              // マップするリソース
        0,                       // サブリソースのインデックス番号
        D3D11_MAP_WRITE_DISCARD, // 書き込みアクセス
        0,                       //
        &MappedResource);        // データの書き込み先ポインタ
                                 // データ書き込み
    CopyMemory(MappedResource.pData, &g_cbCBuffer, sizeof(cbCBuffer));
    // マップ解除
    m_pDeviceContext->Unmap(g_pCBuffer, 0);
}
/////////////////////////////////////////////////////////
//初期化バッファに値を送る。
/////////////////////////////////////////////////////////
void PerticlesComp::sendInitBuffer() {
    HRESULT hr = S_OK;
    // ***************************************
    // 定数バッファのマップ取得

    D3D11_MAPPED_SUBRESOURCE MappedResource;
    hr = m_pDeviceContext->Map(
        g_pInitBuffer,              // マップするリソース
        0,                       // サブリソースのインデックス番号
        D3D11_MAP_WRITE_DISCARD, // 書き込みアクセス
        0,                       //
        &MappedResource);        // データの書き込み先ポインタ
                                 // データ書き込み
    CopyMemory(MappedResource.pData, &CpuGpuBuffers, sizeof(CpuGpuBuffer)*PERTICLES_PIECE_NO);
    // マップ解除
    m_pDeviceContext->Unmap(g_pInitBuffer, 0);

}

void PerticlesComp::Update() {

    // **********************************************************
    // コンピュート・シェーダを使った演算
    // **********************************************************
    Compute();

    chainA = chainA ? 0 : 1;//バッファーの切り替え
    chainB = chainB ? 0 : 1;//バッファーの切り替え

    return;

}

void PerticlesComp::PerticleSet(const int Kind ,const V3 pos, const V3 Velocity, const V2 size) {
    int count = 0;

    while (count < PERTICLES_PIECE_NO) {
        if (CpuGpuBuffers[PerticleWorkNo].BusyFg) {
            PerticleWorkNo++;
            if (PerticleWorkNo >= PERTICLES_PIECE_NO) {
                PerticleWorkNo = 0;
            }
        }
        else {// 空きスロットを見つけた
            CpuGpuBuffers[PerticleWorkNo].Position.x = pos.x;
            CpuGpuBuffers[PerticleWorkNo].Position.y = pos.y;
            CpuGpuBuffers[PerticleWorkNo].Position.z = pos.z;
            CpuGpuBuffers[PerticleWorkNo].Kind = Kind;
            CpuGpuBuffers[PerticleWorkNo].BusyFg = 1;
            CpuGpuBuffers[PerticleWorkNo].Step = 0;
            CpuGpuBuffers[PerticleWorkNo].Velocity = Velocity;
            CpuGpuBuffers[PerticleWorkNo].Size = size;
            PerticleWorkNo++;
            return;
        }
        count++;
    }
    return;
}
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
// 点の描画
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////

#include <TinyText.h>
void PerticlesComp::RenderDisp(MXobj3dCamera* camera,bool dispFg)
{
    DirectX::XMMATRIX P;    // projection matrix
    ID3D11DeviceContext* m_pDeviceContext = MX_DX->m_pDeviceContext;

    float aspect_ratio = MX_DX->vp.Width / MX_DX->vp.Height;

    camera->CameraUpdate();

    P = camera->getProjecttion();
    P = XMMatrixTranspose(P);//転地行列へ
    DirectX::XMMATRIX V;    // view matrix
    {
        DirectX::XMVECTOR  CEyeMX = DirectX::XMLoadFloat4(&camera->CameraEyeMX);
        DirectX::XMVECTOR  CLookAtMX = DirectX::XMLoadFloat4(&camera->CameraLookAtMX);
        DirectX::XMVECTOR  CUpMX = DirectX::XMLoadFloat4(&camera->CameraUpMX);

        V = DirectX::XMMatrixLookAtLH(CEyeMX, CLookAtMX, CUpMX);
    }

    DirectX::XMStoreFloat4x4(&g_cbCBuffer.Projection, P);
    DirectX::XMStoreFloat4x4(&g_cbCBuffer.View, XMMatrixTranspose(V));//転地行列へ　row_major
    g_cbCBuffer.ParticleSize.x = 0.1;
    g_cbCBuffer.ParticleSize.y = 0.1;
    g_cbCBuffer.EyePos = DirectX::XMFLOAT4(camera->CameraEye.x, camera->CameraEye.y, camera->CameraEye.z, 1.0f);
    g_cbCBuffer.FogNear = MXobj3dLight::FogNear;        //霧の始まる位置
    g_cbCBuffer.FogFar = MXobj3dLight::FogFar;        //霧の終わる位置
    g_cbCBuffer.FogColor = MXobj3dLight::FogColor;        //霧の終わる位置

    m_pDeviceContext->UpdateSubresource(g_pCBuffer.p, 0, 0, &g_cbCBuffer, 0, 0);

    // ***************************************
    // VSに定数バッファを設定
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &g_pCBuffer.p);
    // PSに定数バッファを設定
    m_pDeviceContext->PSSetConstantBuffers(0, 1, &g_pCBuffer.p);
    m_pDeviceContext->GSSetConstantBuffers(0, 1, &g_pCBuffer.p);

    // ***************************************

    // IAに頂点バッファを設定
    UINT strides[1] = { sizeof(workBuffer) };
    UINT offsets[1] = { 0 };
    //m_pDeviceContext->IASetVertexBuffers(0, 1, &g_pVerBufferDrawFrom.p, strides, offsets);
    //// IAに入力レイアウト・オブジェクトを設定
    //m_pDeviceContext->IASetInputLayout(m_pVertexLayout.p);
    //// IAにプリミティブの種類を設定 (これを要れないと３回に一回しかジオメトリシェーダーが呼ばれなくなったりします。
    m_pDeviceContext->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_POINTLIST);

    // VSに頂点シェーダを設定
    m_pDeviceContext->VSSetShader(g_pMxGpu_Disp_VS.p, NULL, 0);
    // GSにジオメトリ・シェーダを設定
    m_pDeviceContext->GSSetShader(g_pMxGpu_Disp_GS.p, NULL, 0);

    // PSにピクセル・シェーダを設定
    m_pDeviceContext->PSSetShader(g_pMxGpu_Disp_PS.p, NULL, 0);
    render_texture->Set(0);//テキスチャー
    MX_DX->m_pDeviceContext->PSSetSamplers(0, 1, &mx2dDx->m_pSampler.p);

    UINT mask = 0xffffffff;
    MX_DX->m_pDeviceContext->OMSetBlendState(pBlendState, NULL, mask);

    MX_DX->setRasterrizer(2);

    m_pDeviceContext->VSSetShaderResources(0, 1, &g_pSRV[chainB].p);

    // ***************************************
    // 描画する

///深度バッファを無効に。
    {
    HRESULT hr = S_OK;
    D3D11_DEPTH_STENCIL_DESC depthStencilDesc;
    ZeroMemory(&depthStencilDesc, sizeof(D3D11_DEPTH_STENCIL_DESC));
    depthStencilDesc.DepthEnable = true;
    // 深度/ステンシル・ステート・オブジェクトの作成
    depthStencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO; // 書き込まない。
    depthStencilDesc.DepthFunc = D3D11_COMPARISON_LESS; // 手前の物体を描画
    depthStencilDesc.StencilEnable = FALSE; // ステンシル・テストなし
    depthStencilDesc.StencilReadMask = 0;     // ステンシル読み込みマスク。
    depthStencilDesc.StencilWriteMask = 0;     // ステンシル書き込みマスク。

    SAFE_RELEASE(MX_DX->m_DepthStencilState.p);//
    hr = m_pDevice->CreateDepthStencilState(&depthStencilDesc, &MX_DX->m_DepthStencilState.p);
    //それをデバイスコンテキストに渡す
    _ASSERT_EXPR(SUCCEEDED(hr), hr_trace(hr));
    m_pDeviceContext->OMSetDepthStencilState(MX_DX->m_DepthStencilState, 1);
    }

    if (dispFg)
    m_pDeviceContext->Draw(PERTICLES_PIECE_NO, 0);
    m_pDeviceContext->GSSetShader(NULL, NULL, 0);
    MX_DX->UnBindRenderAndDepthView(1);//ステンシルを有効に

    //バーテックスシェーダーからリソースをはずす
    ID3D11ShaderResourceView* pNullObj = nullptr;
    m_pDeviceContext->VSSetShaderResources(0, 1, &pNullObj);

}

PerticlesComp::~PerticlesComp() {
}

