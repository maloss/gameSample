#pragma once
#include "MXdx.h"
#include <D3Dcommon.h>
#include "MxTexture.h"
#include "PerticlesDispNo.h"

using namespace DirectX;

class PerticlesComp {
//    class Ai2SampleComp : public Singleton<Ai2SampleComp> {
    public:
    HWND m_hWnd;
    ID3D11Device* m_pDevice;
    ID3D11DeviceContext* m_pDeviceContext;

    HRESULT InitComp();

    ~PerticlesComp();

    void Init();
    void Update();
    void sendConstantBuffer();
    void sendInitBuffer();
    void PerticleSet(const int Kind, const V3 pos, const V3 Velocity, const V2 Size);
    int PerticleWorkNo = 0;

    // **********************************************************
    // 計算関係
    void CreateShader(void);//    シェーダーの作成
    void CreateResource(void);//    リソースの作成(バッファ確保)
    void CreateView(void);//    ビューの作成(インターフェイス)
    HRESULT Compute(void);//    コンピュート シェーダを使った演算
    ///////////////////////////////////
    CComPtr <ID3D11ComputeShader> g_pComputeShader2;  // コンピュート・シェーダ
    CComPtr <ID3D11Buffer> g_pBuffer[2] = { NULL, NULL }; // GPUのみのワークバッファ リソース
    CComPtr <ID3D11ShaderResourceView>  g_pSRV[2] = { NULL, NULL }; // シェーダ リソース ビュー
    CComPtr <ID3D11UnorderedAccessView> g_pUAV[2] = { NULL, NULL }; // アンオーダード アクセス ビュー

    CComPtr <ID3D11Buffer> g_pInitBuffer = NULL; // 初期化ワークバッファ リソース
    CComPtr <ID3D11ShaderResourceView>  g_pInitSRV = NULL; // 初期化ワークリソース ビュー

    CComPtr <ID3D11Buffer> g_pToCpuBuffer =  NULL; // CPUへの書き込み用バッファ リソース（stagingの手前）
    CComPtr <ID3D11UnorderedAccessView> g_pToCpuUAV =  NULL ;// アンオーダード アクセス ビュー
    CComPtr <ID3D11Buffer> g_pStagingBuffer = NULL; // リードバック用バッファ リソース
// **********************************************************
// 描画用関係
    void RenderDisp(MXobj3dCamera* camera, bool dispFg);//パーティクル描画処理
    CComPtr <ID3D11Buffer>        g_pCBuffer = NULL;        // 定数バッファ

    std::unique_ptr<MX2dDX>  mx2dDx;

    std::shared_ptr<Texture> render_texture = nullptr;

    CComPtr <ID3D11PixelShader>     g_pMxGpu_Disp_PS = NULL;
    CComPtr <ID3D11GeometryShader>     g_pMxGpu_Disp_GS = NULL;
    CComPtr <ID3D11VertexShader>     g_pMxGpu_Disp_VS = NULL;
    CComPtr <ID3D11InputLayout> m_pVertexLayout;
    CComPtr <ID3D11Buffer>      g_pVerBufferDrawFrom = NULL;  // 頂点バッファ(計算後)のインターフェイス

    ///////////////////////////////////

    CComPtr<ID3D11BlendState> pBlendState;

    // シェーダのコンパイル オプション

#if defined(DEBUG) || defined(_DEBUG)
    UINT g_flagCompile = D3D10_SHADER_DEBUG | D3D10_SHADER_SKIP_OPTIMIZATION
        | D3D10_SHADER_ENABLE_STRICTNESS | D3D10_SHADER_PACK_MATRIX_COLUMN_MAJOR;
#else
    UINT g_flagCompile = D3D10_SHADER_ENABLE_STRICTNESS | D3D10_SHADER_PACK_MATRIX_COLUMN_MAJOR;
#endif

    struct cbCBuffer {
        XMFLOAT4X4 View;       // ビュー変換行列
        XMFLOAT4X4 Projection; // 透視変換行列
        XMFLOAT2   ParticleSize;  // パーティクルの大きさ
        INT32      No;          //
        FLOAT      dummy;      // ダミー
        XMFLOAT4  EyePos;   //カメラ座標
        XMFLOAT4    FogColor;        //霧の色
        FLOAT    FogNear;        //霧の始まる位置
        FLOAT    FogFar;        //霧の終わる位置
        FLOAT    dummy1;
        FLOAT    dummy2;

    };

 //ワークバッファに納めるデータ形式
    struct workBuffer
    {
        XMFLOAT3 Position;      // 座標値
        XMFLOAT3 Velocity;      // 速度
        XMFLOAT3 Force; // 加速度
        INT32    Kind;       // 種類
        INT32    TexNo;       // テキスチャーNO
        INT32    AniNo;      // アニメNo
        INT32   Timer;      // ダミー
        FLOAT Alpha;      //透明度
        XMFLOAT2 Size;      //サイズ
        FLOAT Angle;      //回転角
    };

    //GPU←→CPUのバッファ　３２ビットは４バイト　１６バイト単位で切れ目
    struct CPUGPUBuffer
    {
        INT32      Kind;          //種類
        XMFLOAT3 Position;      // 座標値
        INT32 BusyFg;
        INT32 Step;
        XMFLOAT2  Size;        //サイズ
        FLOAT  Dummy;        //
        XMFLOAT3  Velocity;        //初速度

    }CpuGpuBuffer;
    CPUGPUBuffer CpuGpuBuffers[PERTICLES_PIECE_NO];

    // 定数バッファのデータ
    struct cbCBuffer g_cbCBuffer;

// **********************************************************

        int chainA = 0;//バッファーの切り替え
        int chainB = 1;//バッファーの切り替え

};
