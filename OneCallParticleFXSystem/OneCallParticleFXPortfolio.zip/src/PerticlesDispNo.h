//must be 4*?
//#define PERTICLES_PIECE_NO  1500  //パーティクルの数
//#define PERTICLES_COMP_NO  150  //GPU側のスレッド数

//#define PERTICLES_PIECE_NO  8  //パーティクルの数
//#define PERTICLES_COMP_NO  4  //GPU側のスレッド数

#define PERTICLES_PIECE_NO  15360  //パーティクルの数
#define PERTICLES_COMP_NO  1024  //GPU側のスレッド数

#define KIND_NOP    0//煙のカインド
#define KIND_SMOKE    1//煙のカインド
#define KIND_STAR    2//星のカインド
#define KIND_BLOOD    3//血のカインド

#define TEX_SIZE     256.0f//TEXサイズ
#define TEX_P_SIZE     64.0f//パーティクルのTEXサイズ

#define TEX_SMOKE    1//煙の絵
#define TEX_SMOKE2    2//煙2の絵
#define TEX_STAR    3//星の絵
#define TEX_BLOOD    4//血の絵
