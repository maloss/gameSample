# MxPathSearchSystem

このプロジェクトは、グリッド上での簡易的な経路探索（パスファインディング）を行う C++ サンプルです。  
ダイクストラ法に近いアルゴリズムを用いて、スタートからゴールまでの経路を構築・表示します。

---

## 📂 フォルダ構成

```
MxPathSearchSystem/
├─ src/                        … 探索エンジンのソースコード & 使用例
│   ├─ MxPathSearch.cpp
│   ├─ MxPathSearch.h
│   └─ LaunchPathSearchSample.cpp
└─ README.md
```

---

## 🧪 使用方法

`LaunchPathSearchSample.cpp` をビルド・実行すると、以下の処理が行われます：

- 10×10のグリッドを生成
- (0, 0) → (9, 9) への経路を探索
- `makeRoot()` により `rootPass` を構築
- 経路を順に出力

---

## 📌 注意

このコードは参考として、実装済みのものを抜粋しAIにより整形したものです。  
実行には別途プロジェクト設定や補助コードが必要になる場合があります。
