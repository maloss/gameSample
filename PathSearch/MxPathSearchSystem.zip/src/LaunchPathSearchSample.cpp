#include "src/MxPathSearch.h"
#include <iostream>
#include <memory>
#include <Windows.h>

int main() {
    // 探索システム初期化
    std::shared_ptr<SeachGraph> graph = std::make_shared<SeachGraph>();
    graph->Init(10, 10);  // 10x10のグリッドを例として初期化

    // スタートとゴール設定
    graph->setStart(0, 0);
    graph->setGoal(9, 9);

    // 探索実行
    graph->Start();

    // 経路構築（ゴールからスタートへ遡る）
    graph->makeRoot();

    // 経路出力（start → goal 方向）
    std::cout << "経路：" << std::endl;
    for (auto it = graph->rootPass.rbegin(); it != graph->rootPass.rend(); ++it) {
        auto edge = *it;
        std::cout << "From (" << edge->from->pos.x << ", " << edge->from->pos.y << ") → "
                  << "To (" << edge->to->pos.x << ", " << edge->to->pos.y << ")" << std::endl;
    }

    return 0;
}
